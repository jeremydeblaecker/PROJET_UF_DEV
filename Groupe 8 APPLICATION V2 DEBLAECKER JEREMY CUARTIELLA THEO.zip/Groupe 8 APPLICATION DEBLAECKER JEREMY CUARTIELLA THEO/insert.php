<?php

$link = mysqli_connect("localhost", "root", "", "plante");
 
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
$nom = mysqli_real_escape_string($link, $_REQUEST['nom']);
$description = mysqli_real_escape_string($link, $_REQUEST['description']);
$humidite_air = mysqli_real_escape_string($link, $_REQUEST['humidite_air']);
$humidite_sol = mysqli_real_escape_string($link, $_REQUEST['humidite_sol']);
$temperature = mysqli_real_escape_string($link, $_REQUEST['temperature']);
$luminosite = mysqli_real_escape_string($link, $_REQUEST['luminosite']);

 
$sql = "INSERT INTO plante (nom, description, humidite_air, humidite_sol, temperature, luminosite) VALUES ('$nom', '$description', '$humidite_air', '$humidite_sol', '$temperature', '$luminosite')";
if(mysqli_query($link, $sql)){
    header("location:index.php? note=success");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
mysqli_close($link);
?>