
<!DOCTYPE html>
<html lang="fr" dir="ltr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta charset="UTF-8">
        <title>UF DEV</title>
        <link rel="stylesheet" href="style.css">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
    </head>
    <body>

<div id='center'>
    <div class="info">
        <h4>Les données de votre plante sont :</h4>        
        <div id="temp"></div>
        <div id="air"></div>
        <div id="sol"></div>
    </div>
</div>

<div class="container">
   <br>
   <div class="form-group">
    <div class="input-group">
     <span class="input-group-addon">Rechercher</span>
     <input type="text" name="search_text" id="search_text" placeholder="Nom de la plante..." class="form-control" />
    </div>
   </div>
   <br />
   <div id="result"></div>
  </div>

<<div id='center'>
  <form action="insert.php" method="post">
    <p>
        <label for="nom">Nom:</label><br>
        <input type="text" name="nom" id="nom">
    </p>
    <p>
        <label for="description">Description :</label><br>
        <input type="text" name="description" id="description">
    </p>
    <p>
        <label for="humidite_air">Humidité air:</label><br>
        <input type="text" name="humidite_air" id="humidite_air">
    </p>
    <p>
        <label for="humidite_sol">Humidité sol:</label><br>
        <input type="text" name="humidite_sol" id="humidite_sol">
    </p>
    <p>
        <label for="temperature">Température:</label><br>
        <input type="text" name="temperature" id="temperature">
    </p>
    <p>
        <label for="luminosite">Luminosité:</label><br>
        <input type="text" name="luminosite" id="luminosite">
    </p>
    <input type="submit" value="Envoyer">
    </div>
</form>

  <script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>
        <script src="JS/api.js"></script>
        <script src="JS/adafruit.js"></script>

    </body>
    
</html>