<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "plante");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM plante 
  WHERE nom LIKE '%".$search."%'
 ";
}
else
{
 $query = "
  SELECT * FROM plante ORDER BY nom
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     <th>Nom</th>     
	 <th>Température</th>
     <th>Humidité Air</th>
	 <th>Humidité Sol</th>

     <th>Luminosité</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
    <td>'.$row["nom"].'</td>    
	<td>'.$row["temperature"].'</td>
    <td>'.$row["humidite_air"].'</td>
	<td>'.$row["humidite_sol"].'</td>

    <td>'.$row["luminosite"].'</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Aucune plante trouvée';
}

?>