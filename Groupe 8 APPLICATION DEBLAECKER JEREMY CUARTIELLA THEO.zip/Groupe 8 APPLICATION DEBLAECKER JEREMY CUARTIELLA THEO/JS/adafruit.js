sendQuery('https://io.adafruit.com/api/v2/andiore/feeds?x-aio-key=a8dbad903d5848ebad0c187860b5247b');

sendQueryWithCallback(
        'https://io.adafruit.com/api/v2/andiore/feeds?x-aio-key=a8dbad903d5848ebad0c187860b5247b',
        'GET',
        () => {console.log("Bon !")}
    );
    function refreshData() {
    sendQueryWithCallback(
            'https://io.adafruit.com/api/v2/andiore/feeds?x-aio-key=a8dbad903d5848ebad0c187860b5247b',
            'GET',
            (response) => {
                response = JSON.parse(response);
                console.log("Refreshed");
                console.log(response)
                
                document.getElementById("temp").innerHTML = `Température: ${response[5]['last_value']}°C`;
                document.getElementById("air").innerHTML = `Humidité dans l'air:  ${response[2]['last_value']}%`;
                document.getElementById("sol").innerHTML = `Humidité du sol: ${response[6]['last_value']}%`;


        });
        setTimeout(refreshData, 10000);

    };
    refreshData();