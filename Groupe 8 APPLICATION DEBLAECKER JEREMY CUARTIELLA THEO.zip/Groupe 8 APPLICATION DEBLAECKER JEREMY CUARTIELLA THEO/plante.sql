-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 27 juin 2019 à 23:55
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `connectecd_flower`
--

-- --------------------------------------------------------

--
-- Structure de la table `plante`
--

DROP TABLE IF EXISTS `plante`;
CREATE TABLE IF NOT EXISTS `plante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(75) NOT NULL,
  `categorie` int(11) DEFAULT NULL,
  `description` text,
  `photos` varchar(3046) DEFAULT NULL,
  `humidite` text,
  `temperature` text,
  `luminosite` text,
  `periode_debut` date DEFAULT NULL,
  `periode_fin` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `plante`
--

INSERT INTO `plante` (`id`, `nom`, `categorie`, `description`, `photos`, `humidite`, `temperature`, `luminosite`, `periode_debut`, `periode_fin`) VALUES
(1, 'Tulipe d\'Agen', 1, 'tulipe de france', 'https://france3-regions.francetvinfo.fr/nouvelle-aquitaine/sites/regions_france3/files/styles/top_big/public/assets/images/2015/04/08/bonne_tulipe4.jpg?itok=vO0pkq0V', 'peu d\'humidité', 'température élever', 'Bien éclairé', NULL, NULL),
(2, 'Sétaire_verticillée', NULL, 'Plante annuelle de 30-80 cm, glabre, à racine fibreuse \r\n- tige dressée ou ascendante, rude au sommet \r\n- feuilles vertes, larges de 5-10 mm à ligule courte poilue \r\n- panicule spiciforme longue de 5-10 cm, cylindrique, un peu interrompue à la base et comme verticillée, verte ou un peu violacée, très rude de bas en haut et accrochante, à axe scabre \r\n- soies 2, vertes ou violacées saillantes, à denticulés réfléchis \r\n- épillets elliptiques, obtus \r\n- glumes très inégales, la supérieure égalant environ la fleur \r\n- glumelles fertiles finement ponctuées. ', 'http://sauvagesdepaca.fr/sites/default/files/styles/flexslider_full/public/galerie-image/Setaria-verticillata-%28L.%29-par-Marie-PORTAS-Licence-cc-by-sa.jpg?itok=tDLpQ8XS', 'peu d\'humidité', 'température élever', 'Bien éclairé', NULL, NULL),
(3, 'Pariétaire_de_Judée', NULL, '-', 'https://api.tela-botanica.org/img:000173506CRS.jpg', 'peu d\'humidité', 'température élever', 'normal', NULL, NULL),
(4, 'Renouée_des_oiseaux', NULL, '- . Plante annuelle, rarement pérennante, de 10-80 cm, glabre ou pubérulente, à tiges grêles, étalées-diffuses ou dressées, striées, plus ou moins feuillées jusqu\'au sommet \r\n- feuilles ovales, elliptiques ou lancéolées, planes, finement veinées en dessous \r\n- gaines scarieuses et lacérées au sommet, striées d\'environ 6 nervures \r\n- fleurs blanchâtres ou rosées, 1-4 subsessiles à l\'aisselle des feuilles \r\n- fruits de 2 à 2 12 mm, trigones, finement striés, ternes ou vaguement luisants, dépassant à peine ou point le périanthe. Très polymorphe. Varie à feuilles épaisses, glaucescentes, un peu roulées, gaines grandes, fruits plus gros (P. littorale Link, non G. G.). ', 'https://api.tela-botanica.org/img:000187926CRS.jpg', 'peu d\'humidité', 'normal', 'bien eclairé', NULL, NULL),
(5, 'Mercuriale_annuelle', NULL, '- . Plante annuelle de 10-50 cm, glabrescente, à racine pivotante \r\n- tige herbacée\r\nVert et plat ou ayant la consistance molle de l\' herbe, par opposition à coloré ou ligneux., rameuse et feuillée dès la base \r\n- feuilles d\'un vert clair, molles, ciliées, pétiolées, ovales ou ovales-lancéolées, lâchement crénelées-dentées, ordinairement arrondies à la base \r\n- fleurs mâles en glomérules formant un épi assez long, les femelles solitaires et subsessiles \r\n- capsule large de 3-4 mm, hispides à poils épaissis à la base \r\n- graines petites, ovoïdes, gris clair. Varie, dans le Midi, à fleurs monoïques, les mâles pédonculées au milieu des femelles subsessiles (M. ambigua L.) \r\n- à plante plus petite, feuilles glabres et à peine dentées, capsule peu hérissée (M. huetii Hanry). ', 'https://api.tela-botanica.org/img:000741834CRS.jpg', 'normal', 'normal', 'bien éclairé', NULL, NULL),
(6, 'Laiteron_délicat', NULL, '- Plante bisannuelle ou vivace à tige de 2-4 dm, dressée, glabre, très rameuse souvent dès la base, à rameaux étalés ou diffus \r\n- feuilles minces, très molles, embrassant la tige par deux oreillettes très aiguës, pennatiséquées, à segments opposés ovales, lancéolés ou presque linéaires, atténués à la base et parfois pétiolulés \r\n- capitules souvent floconneux à la base, longuement pédoncules en corymbe lâche \r\n- akènes bruns, oblongs, atténués à la base, finement striés \r\n- fleurs jaunes. ', 'https://api.tela-botanica.org/img:000216493CRS.jpg', 'sec', 'température très élever', 'bien éclairé', NULL, NULL),
(7, 'Euphorbe_réveil-matin', NULL, '- . Plante annuelle de 10-50 cm, glabrescente, à racine pivotante \r\n- tige épaisse, dressée ou ascendante, ordinairement solitaire \r\n- feuilles éparses, obovales en coin, obtuses, denticulées dans leur moitié supérieure, les ombellaires plus grandes \r\n- ombelle large, concave, à 5 rayons allongés, trichotomes puis dichotomes \r\n- bractées obovales, inégales \r\n- glandes entières \r\n- capsule de 3-5 mm, glabre et lisse, à coques arrondies \r\n- styles à peine bifides \r\n- graines de 2 mm, ovoïdes, brunes, réticulées-alvéolées, caronculées. ', 'https://api.tela-botanica.org/img:000039910CRS.jpg', 'normal', 'normal', 'bien éclairé', NULL, NULL),
(8, 'Centranthe_lilas_Espagne', NULL, '- . Plante vivace de 30-80 cm, glabre et glauque, à souche épaisse, odorante \r\n- tiges dressées, cylindriques, striées, lisses, creuses, simples ou rameuses \r\n- feuilles ovales ou elliptiques-lancéolées, longues de 8-12 cm et larges de 2-4, entières ou à peine dentelées, les inférieures pétiolées, les supérieures sessiles, à plusieurs nervures divergentes dés la base \r\n- fleurs rouges ou blanches, odorantes, en corymbe serré, s\'allongeant ensuite en panicule trichotome, à rameaux dressés \r\n- corolle à éperon linéaire 1-2 fois plus long que l\'ovaire, égalant presque le tube \r\n- étamine saillante \r\n- fruit glabre. ', 'https://api.tela-botanica.org/img:000102662CRS.jpg', 'normal', 'normal', 'eclairé', NULL, NULL),
(9, 'Buddléia_arbre_aux_papillons', 1, '-', 'https://www.plantes-et-nature.fr/3405-large_default/buddleia-davidii-empire-blue-arbre-aux-papillons.jpg', 'normal', 'normal', 'bien éclairé', NULL, NULL),
(10, 'Ailante_faux-vernis-du-Japon', NULL, '-', 'https://api.tela-botanica.org/img:000252160CRS.jpg', 'peu d\"humidité', 'normal', 'très bien éclairé', NULL, NULL),
(11, 'coquelicot', NULL, '- . Plante annuelle, velue-hérissée \r\n- tige de 20-60 cm, dressée, rameuse \r\n- feuilles pennatipartites, à segments lancéolés-aigus, incisés-dentés, les caulinaires sessiles, à segment terminal très développé \r\n- pédoncules à poils très étalés \r\n- fleurs d\'un rouge vif, grandes \r\n- filets des étamines filiformes \r\n- stigmates 7-12, sur un disque lobé, à lobes se recouvrant par les bords \r\n- capsule courtement obovale, glabre. Plante polymorphe.', 'https://api.tela-botanica.org/img:000244988CRS.jpg', 'normal', 'normal', 'très bien éclairé', NULL, NULL),
(13, 'Sapin_blanc', NULL, '-', 'https://api.tela-botanica.org/img:002080210CRS.jpg', 'bien humide', 'température froide', 'très bien éclairé', NULL, NULL),
(14, 'Aneth', NULL, '- . Plante annuelle de 20-50 cm, glabre, glaucescente, fétide, à racine pivotante \r\n- tige grêle, striée, creuse \r\n- feuilles tripennatiséquées, toutes finement divisées en lanières filiformes, les supérieures sessiles sur une gaine plus courte que le limbe \r\n- fleurs jaunes, en ombelles à 15-30 rayons inégaux \r\n- involucre et involucelle nuls \r\n- calice à limbe nul \r\n- pétales entiers, suborbiculaires-tronqués, à pointe courbée en dedans \r\n- fruit ovale-elliptique, comprimé par le dos, entouré d\'un large rebord plan \r\n- méricarpes à 5 côtes, les trois dorsales saillantes, filiformes, carénées, les deux marginales dilatées en aile aplanie \r\n- graine à face commissurale plane.', 'https://api.tela-botanica.org/img:000238303CRS.jpg', 'très peu d\"humidité', 'normal', 'bien éclairé', NULL, NULL),
(15, 'Gueule_de_lion', NULL, '- . Plante vivace de 30-80 cm, glabre inférieurement, pubescente, glanduleuse dans le haut \r\n- tiges dressées, simples ou rameuses \r\n- feuilles opposées ou alternes, lancéolées ou lancéolées-linéaires, entières, glabres \r\n- fleurs purpurines ou d\'un blanc jaunâtre, grandes, rapprochées en grappe terminale munie de courtes bractées \r\n- pédicelles égalant le calice et la bractée \r\n- calice poilu, à lobes ovales-obtus, 4-5 fois plus courts que la corolle \r\n- corolle de 3-4 cm, poilue, à base gibbeuse \r\n- capsule oblique ovale, poilue, plus longue que le calice. ', 'https://api.tela-botanica.org/img:000237156CRS.jpg', 'normal', 'température bien élever', 'normal', NULL, NULL),
(18, 'Raifort', NULL, '- Racine\r\nAxe souterrain ou aérien toujours dépourvu de feuilles. L\'état ancestral d\'une racine est d\'assurer les fonctions de fixation dans le sol et d\'absorption de l\'eau et des nutriments. Au cours de la germination d\'une graine, la radicule (racine primaire de l\'embryon) se développe en racine principale à géotropisme positif qui se ramifie, les ramifications les plus fines portant des poils absorbants. Des racines qualifiées de \"racines adventives\" peuvent naître des tiges. Les racines peuvent assurer différentes fonctions spécialisées (fixation sur des supports variés, assimilation chlorophyllienne, organes de réserve...). annuelle, bisannuelle ou pérennante, grêle, dure, pivotante \r\n- tige de 20-60 cm, rameuse \r\n- feuilles inférieures lyrées, les supérieures oblongues, dentées \r\n- fleurs jaunes, parfois blanchâtres ou violacées \r\n- siliques étalées-dressées, bosselées, se divisant par des étranglements en articles transversaux, ovoïdes ou oblongs, osseux, striés en long \r\n- bec 4-5 fois plus long que le dernier article. Varie à articles subglobuleux et à bec 1-2 fois plus long que le dernier article (R. maritimus Sm.) \r\n- à articles peu nombreux, peu marqués, à bec 2-3 fois plus long que le dernier (R. landra Mor.). ', 'https://api.tela-botanica.org/img:000155686CRS.jpg', 'normal', 'normal', 'très bien éclairé', NULL, NULL),
(19, 'Estragon', NULL, '-', NULL, 'bien humide', 'normal', 'bien éclairé', NULL, NULL),
(20, 'Râpette', NULL, '- . Plante annuelle de 20-60 cm, hérissée-scabre, à tiges couchées-diffuses, faibles, rameuses dès la base \r\n- feuilles rudes, ciliées, elliptiques-oblongues, pétiolées ou atténuées à la base, les florales opposées \r\n- fleurs bleuâtres, peu apparentes, opposées aux feuilles \r\n- pédicelles très courts, à la fin recourbés \r\n- calice irrégulier, d\'abord à 5 lobes lancéolés, ensuite foliacé, comprimé en 2 valves planes contiguës, sinuées-dentées, veinées en réseau \r\n- corolle égalant le calice, en entonnoir, à tube court, à gorge fermée par 5 écailles obtuses convexes et conniventes, à 5 lobes obtus \r\n- carpelles contigus, ovales-obtus, verruqueux, soudés à l\'axe central par le sommet de leur angle interne. ', 'https://api.tela-botanica.org/img:000223335CRS.jpg', 'peu d\"humidité', 'normal', 'bien éclairé', NULL, NULL),
(21, 'Cétérach', NULL, '- . Plante vivace de 5-15 cm, à souche courte, épaisse, gazonnante \r\n- feuilles en touffe, roulées en crosse dans leur jeune âge, étalées, à pétiole court et couvert d\'écailles, étroitement oblongues, pennatiséquées, à lobes courts, ovales-obtus, entiers ou crénelés, alternes, confluents, épais, glabres et verts en dessus, couverts en dessous d\'écailles brillantes d\'abord argentées puis roussâtres \r\n- fructifications disposées à la face inférieure des feuilles en sores allongés, droits, épars, placés obliquement sur la nervure médiane, dépourvus d\'indusie', 'https://api.tela-botanica.org/img:000714218CRS.jpg', 'très peu d\'humidité', 'température élever', 'bien éclairé', NULL, NULL),
(23, 'Belladone', NULL, '- . Plante vivace atteignant 1 mètre et plus, verte, finement pubescente, fétide \r\n- feuilles supérieures géminées, inégales, toutes pétiolées, ovales-acuminées, nervées, entières ou un peu sinuées \r\n- fleurs d\'un pourpre brunâtre, axillaires, solitaires ou géminées, penchées, pédonculées \r\n- calice pubescent, divisé jusqu\'aux 23 en 5 lobes ovales-acuminés, peu accrescents, d\'abord en cloche, à la fin étalés en étoile sous le fruit \r\n- corolle de 20-30 cm, pubérulente, tubuleuse en cloche, à lobes courts \r\n- 5 étamines, inégales, incluses, à anthères non conniventes, s\'ouvrant en long \r\n- baie à 2 loges, globuleuse et grosse comme une cerise, noire et luisante, plus courte que le calice, très vénéneuse. ', 'https://api.tela-botanica.org/img:000853831CRS.jpg', 'normal', 'normal', 'bien éclairé', NULL, NULL),
(26, 'Bellardie', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 'Pâquerette', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 'Biscutelle', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 'Lunetière', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 'Chlorette', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 'Rouche', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 'Bourrache', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 'Colza', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(34, 'Rave', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 'Piptathère_faux-millet', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
